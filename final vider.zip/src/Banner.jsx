import React from 'react';
import bannerImg from "./assets/image.png";
import { Container, Grid, Typography, Box } from "@mui/material";

function Banner() {
    return (
        <Container>
            <Grid container style={{ marginTop: "100px", marginBottom: "100px" }}>
                <Grid items sm={12} md={6} style={{ backgroundColor: "#182F53", width: "100%" }}>
                    <Typography variant="h4" style={{ color: "white", margin: "30px", fontWeight: "bold" }}>
                        Assurance, Accurate & Affordable
                    </Typography>
                    <Box style={{ display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", marginLeft: "30px" }}>
                        <Typography variant="paragraph" style={{ color: "#FFFFFF91", fontWeight: "bold", margin: "5px" }}>Our dream is to standardize the working style of professionals in a automated manner to match it with the applicable laws in the country.</Typography><br></br>
                        <Typography variant="paragraph" style={{ color: "#FFFFFF91", fontWeight: "bold", margin: "5px" }}>Thus, Vider was formed which integrates all the professional services under one roof and enables real time processing</Typography><br></br>
                        <Typography variant="paragraph" style={{ color: "#FFFFFF91", fontWeight: "bold", margin: "5px" }}> We actually bring together the best and the brightest in professional services.</Typography>
                    </Box>
                    <Box sx={{ display: "flex", marginLeft: "30px", gap: "5px", overFlow: "hidden" }}>
                        <Box>
                            <Typography variant='h4' sx={{ fontWeight: "bold", color: "orange" }}> 5X </Typography>
                            <Typography variant='p' sx={{ color: "#FFFFFF91", }}> Increase in managing tasks and overall efficiency by using our feature - INFO-PRO</Typography>
                        </Box>
                        <Box>
                            <Typography variant='h4' sx={{ fontWeight: "bold", color: "#46D2E4" }}> 3X </Typography>
                            <Typography variant='p' sx={{ color: "#FFFFFF91", }}> Increase in Productivity and Faster Turnaround time for completion of a Task through our features - Reminders & E-Sign</Typography>
                        </Box>
                        <Box>
                            <Typography variant='h4' sx={{ fontWeight: "bold", color: '#46E483' }}> 10X </Typography>
                            <Typography variant='p' sx={{ color: "#FFFFFF91", }}>By Partnering with Microsoft as CSPP, Our cloud storage solution will increase efficiency and our product PRISM increases the scope of Professionals & Hence Increases revenue.</Typography>
                        </Box>
                    </Box>
                </Grid>
                <Grid items sm={12} md={6}>
                    <img src={bannerImg} alt="banner" style={{ height: "630px", width: "600px" }} />
                </Grid>
            </Grid>
        </Container>

        // <div style={{ display: "flex", justifyContent: "center", alignItems: "center", marginTop: "40px", marginBottom: "40px" }}>
        //     <img src={BannerImg} alt="img" style={{ height: "600px", width: "70%" }} />
        // </div>
    )
}

export default Banner
